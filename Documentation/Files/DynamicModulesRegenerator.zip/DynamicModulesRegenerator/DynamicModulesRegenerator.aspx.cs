﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Sitefinity.DynamicModules.Builder;
using Telerik.Sitefinity.DynamicModules.Builder.Events;
using Telerik.Sitefinity.DynamicModules.Builder.Model;
using Telerik.Sitefinity.Services;

namespace SitefinityWebApp
{
    public partial class DynamicModulesRegenerator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var moduleBuilderManager = ModuleBuilderManager.GetManager().Provider;
                var dynamicTypes = moduleBuilderManager.GetDynamicModuleTypes().ToList();
                foreach (var dynamicType in dynamicTypes)
                {
                    ListItem item = new ListItem();
                    item.Text = dynamicType.GetTitle();
                    item.Value = dynamicType.Id.ToString();
                    this.CheckBoxList1.Items.Add(item);
                }
            }
        }

        protected void UpdateAllBtn_Click(object sender, EventArgs e)
        {
            var moduleBuilderManager = ModuleBuilderManager.GetManager();
            var moduleBuilderProvider = moduleBuilderManager.Provider;
            var dynamicTypes = moduleBuilderProvider.GetDynamicModuleTypes().ToList();

            this.RaiseUpdateEvent(moduleBuilderManager, dynamicTypes);
        }

        protected void UpdateSelectedBtn_Click(object sender, EventArgs e)
        {
            var selectedDynamicTypeIds = this.CheckBoxList1.Items.Cast<ListItem>()
                .Where(li => li.Selected)
                .Select(li => li.Value)
                .ToList();
            var moduleBuilderManager = ModuleBuilderManager.GetManager();
            var moduleBuilderProvider = moduleBuilderManager.Provider;
            var dynamicTypes = moduleBuilderProvider.GetDynamicModuleTypes().Where(t => selectedDynamicTypeIds.Contains(t.Id.ToString())).ToList();

            this.RaiseUpdateEvent(moduleBuilderManager, dynamicTypes);
        }

        private void RaiseUpdateEvent(ModuleBuilderManager moduleBuilderManager, IEnumerable<DynamicModuleType> dynamicTypes)
        {
            foreach (var dynamicType in dynamicTypes)
            {
                BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
                MethodInfo minfo = typeof(ModuleBuilderManager).GetMethod("LoadDynamicModuleTypeGraph", bindingFlags);
                minfo.Invoke(moduleBuilderManager, new object[] {dynamicType, false, false});

                var updatingEvent = new DynamicModuleTypeUpdatingEvent(dynamicType);
                EventHub.Raise(updatingEvent);
            }
        }
    }

    internal class DynamicModuleTypeUpdatingEvent : IDynamicModuleTypeItemEvent, IDynamicModuleTypeUpdatingEvent
    {
        public DynamicModuleTypeUpdatingEvent(DynamicModuleType item)
            : base()
        {
            this.Item = item;
            this.ChangedProperties = new Dictionary<string, Telerik.Sitefinity.Data.Events.PropertyChange>();
            this.ShouldUpdateWidgetTemplates = true;
        }

        /// <inheritdoc />
        public bool ShouldUpdateWidgetTemplates
        {
            get;
            private set;
        }

        public string Origin
        {
            get;
            set;
        }

        public IDictionary<string, Telerik.Sitefinity.Data.Events.PropertyChange> ChangedProperties
        {
            get;
            private set;
        }

        public DynamicModuleType Item
        {
            get;
            private set;
        }
    }
}